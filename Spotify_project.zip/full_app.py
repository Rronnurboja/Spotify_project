# spotify_app_enhanced.py
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
import plotly.express as px
import plotly.graph_objects as go

# Page config
st.set_page_config(
    page_title="Spotify Mood Mixer", 
    layout="wide", 
    page_icon="🎵",
    initial_sidebar_state="expanded"
)

st.title("🎵 Spotify Mood DJ")
st.caption("Intelligent mood-based music recommendation system")

# ========== LOAD AND PREPARE DATA ==========
@st.cache_data
def load_data():
    df = pd.read_csv("data/SpotifyFeatures.csv")
    df = df.drop_duplicates(subset='track_id').reset_index(drop=True)
    df['duration_min'] = df['duration_ms'] / 60000
    
    # Normalize loudness (-60 to 0 dB to 0-1 scale)
    df['loudness_norm'] = (df['loudness'] - df['loudness'].min()) / \
                          (df['loudness'].max() - df['loudness'].min())
    
    # Create mood labels based on valence and energy
    df['mood_category'] = pd.cut(
        df['valence'], 
        bins=[0, 0.3, 0.6, 1], 
        labels=['Sad', 'Neutral', 'Happy']
    )
    
    return df

df = load_data()

# Key mapping for musical keys
key_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
key_map = {i: key_names[i] for i in range(12)}

# ========== SIDEBAR CONTROLS ==========
st.sidebar.header("🎛️ Controls")

# Mood selector with detailed profiles
mood_profiles = {
    "😊 Happy & Energetic": {
        "valence": 0.8, "energy": 0.8, "danceability": 0.7,
        "acousticness": 0.1, "loudness_norm": 0.8, "tempo": 125
    },
    "😢 Sad & Melancholic": {
        "valence": 0.2, "energy": 0.3, "acousticness": 0.7,
        "mode": 0, "tempo": 70, "loudness_norm": 0.3
    },
    "💃 Dance Party": {
        "danceability": 0.9, "energy": 0.85, "valence": 0.7,
        "tempo": 120, "loudness_norm": 0.9, "acousticness": 0.05
    },
    "🧘 Calm & Relaxed": {
        "acousticness": 0.8, "energy": 0.2, "valence": 0.6,
        "loudness_norm": 0.2, "tempo": 70, "danceability": 0.4
    },
    "🎸 Rock Out": {
        "energy": 0.9, "loudness_norm": 0.95, "valence": 0.6,
        "acousticness": 0.1, "danceability": 0.5, "tempo": 140
    },
    "🎹 Chill Study": {
        "instrumentalness": 0.7, "speechiness": 0.05,
        "acousticness": 0.4, "energy": 0.4, "valence": 0.5,
        "tempo": 90, "danceability": 0.5
    },
    "✨ Custom Mood": {}
}

selected_mood = st.sidebar.selectbox(
    "Select Mood",
    list(mood_profiles.keys()),
    index=0,
    help="Choose a mood profile or create your own custom mood"
)

# Feature sliders
st.sidebar.subheader("🎚️ Audio Features")

if selected_mood == "✨ Custom Mood":
    col1, col2 = st.sidebar.columns(2)
    with col1:
        dance_target = st.slider("Danceability", 0.0, 1.0, 0.5, 0.05)
        energy_target = st.slider("Energy", 0.0, 1.0, 0.5, 0.05)
        valence_target = st.slider("Happiness", 0.0, 1.0, 0.5, 0.05)
    with col2:
        acousticness_target = st.slider("Acousticness", 0.0, 1.0, 0.5, 0.05)
        tempo_target = st.slider("Tempo (BPM)", 60, 200, 120, 10)
        loudness_target = st.slider("Loudness", 0.0, 1.0, 0.5, 0.05)
    
    dance_range = st.sidebar.slider("Danceability Range", 0.1, 0.5, 0.3, 0.05)
    energy_range = st.sidebar.slider("Energy Range", 0.1, 0.5, 0.3, 0.05)
    valence_range = st.sidebar.slider("Happiness Range", 0.1, 0.5, 0.3, 0.05)
else:
    preset = mood_profiles[selected_mood]
    dance_target = preset.get("danceability", 0.5)
    energy_target = preset.get("energy", 0.5)
    valence_target = preset.get("valence", 0.5)
    acousticness_target = preset.get("acousticness", 0.5)
    tempo_target = preset.get("tempo", 120)
    loudness_target = preset.get("loudness_norm", 0.5)
    
    dance_range = 0.3
    energy_range = 0.3
    valence_range = 0.3
    acousticness_range = 0.3

tempo_range = st.sidebar.slider("Tempo Range", 10, 50, 20, 5)

# Genre filter
st.sidebar.subheader("🎵 Genres")
all_genres = sorted(df['genre'].unique())
selected_genres = st.sidebar.multiselect(
    "Filter genres",
    all_genres,
    default=['Pop', 'Rock'] if 'Pop' in all_genres else [],
    help="Select genres to include in recommendations"
)

# Musical settings
st.sidebar.subheader("🎼 Musical Settings")
with st.sidebar.expander("Key & Mode Filters"):
    key_filter_enabled = st.checkbox("Filter by Musical Key", False)
    if key_filter_enabled:
        key_options = ['Any'] + key_names
        selected_key = st.selectbox("Key", key_options, index=0)
        
        compatible_mode = st.checkbox("Include compatible keys (harmonic mixing)", True)
    
    mode_filter = st.checkbox("Filter by Mode", False)
    if mode_filter:
        selected_mode = st.radio("Mode", ["Major", "Minor", "Both"], index=2)

# Advanced options
with st.sidebar.expander("⚙️ Advanced Options"):
    min_popularity = st.slider("Minimum Popularity", 0, 100, 40)
    max_duration = st.slider("Max Song Length (min)", 1.0, 10.0, 6.0, 0.5)
    instrumental_threshold = st.slider("Max Instrumentalness", 0.0, 1.0, 1.0, 0.1)
    speechiness_threshold = st.slider("Max Speechiness", 0.0, 1.0, 1.0, 0.1)

# ========== HELPER FUNCTIONS ==========
def calculate_similarity(target_song, candidate_songs, genre_aware=True):
    """Calculate similarity between target song and candidate songs."""
    
    # Genre-based feature weights
    genre_weights = {
        'pop': {'danceability': 0.25, 'energy': 0.20, 'valence': 0.20, 
                'tempo': 0.10, 'loudness_norm': 0.10, 'acousticness': 0.10,
                'instrumentalness': 0.05},
        'rock': {'energy': 0.30, 'loudness_norm': 0.25, 'valence': 0.15,
                 'danceability': 0.10, 'tempo': 0.10, 'acousticness': 0.05,
                 'instrumentalness': 0.05},
        'jazz': {'instrumentalness': 0.30, 'acousticness': 0.25, 'tempo': 0.15,
                 'energy': 0.10, 'valence': 0.10, 'danceability': 0.05,
                 'loudness_norm': 0.05},
        'hip hop': {'danceability': 0.25, 'energy': 0.20, 'speechiness': 0.20,
                    'loudness_norm': 0.15, 'valence': 0.10, 'tempo': 0.10},
        'electronic': {'danceability': 0.30, 'energy': 0.25, 'tempo': 0.20,
                       'loudness_norm': 0.15, 'valence': 0.10},
        'classical': {'instrumentalness': 0.40, 'acousticness': 0.30,
                      'energy': 0.10, 'valence': 0.10, 'tempo': 0.10},
        'default': {'danceability': 0.20, 'energy': 0.20, 'valence': 0.20,
                    'tempo': 0.10, 'loudness_norm': 0.10, 'acousticness': 0.10,
                    'instrumentalness': 0.10}
    }
    
    similarities = []
    
    for _, song in candidate_songs.iterrows():
        # Get appropriate weights
        genre_key = 'default'
        song_genre = str(song['genre']).lower()
        for key in genre_weights:
            if key in song_genre:
                genre_key = key
                break
        
        weights = genre_weights[genre_key]
        
        # Calculate weighted similarity
        similarity_score = 0
        for feature, weight in weights.items():
            if feature in target_song and feature in song:
                # Normalize difference to 0-1 range
                if feature == 'tempo':
                    max_diff = 200  # BPM range
                    diff = abs(float(target_song[feature]) - float(song[feature])) / max_diff
                else:
                    diff = abs(float(target_song[feature]) - float(song[feature]))
                
                similarity_score += weight * (1 - min(diff, 1))
        
        similarities.append(similarity_score)
    
    return similarities

def get_harmonic_compatible_keys(key_index):
    """Return keys that are harmonically compatible (DJ mixing)."""
    # Circle of fifths compatibility
    compatible_map = {
        0: [0, 7, 5],    # C with G, F
        1: [1, 8, 6],    # C# with G#, F#
        2: [2, 9, 7],    # D with A, G
        3: [3, 10, 8],   # D# with A#, G#
        4: [4, 11, 9],   # E with B, A
        5: [5, 0, 10],   # F with C, A#
        6: [6, 1, 11],   # F# with C#, B
        7: [7, 2, 0],    # G with D, C
        8: [8, 3, 1],    # G# with D#, C#
        9: [9, 4, 2],    # A with E, D
        10: [10, 5, 3],  # A# with F, D#
        11: [11, 6, 4]   # B with F#, E
    }
    return compatible_map.get(key_index, [key_index])

# ========== MAIN TABS ==========
tab1, tab2, tab3, tab4 = st.tabs(["🔍 Smart Search", "🎧 Create Playlist", "📊 Explore Data", "📈 Mood Analysis"])

with tab1:
    st.header("Find Similar Songs")
    
    col1, col2, col3 = st.columns([3, 2, 1])
    with col1:
        song_query = st.text_input("Song Name", "Shape of You", 
                                 help="Enter song name or part of it")
    with col2:
        artist_query = st.text_input("Artist Name", "Ed Sheeran",
                                   help="Enter artist name (optional)")
    with col3:
        st.write("")
        st.write("")
        search_btn = st.button("🔍 Search", type="primary", use_container_width=True)
    
    if search_btn and song_query:
        with st.spinner("Finding similar songs..."):
            # Find target song
            mask = (df['track_name'].str.contains(song_query, case=False, na=False))
            if artist_query:
                mask = mask & (df['artist_name'].str.contains(artist_query, case=False, na=False))
            
            if mask.any():
                target = df[mask].iloc[0]
                
                # Display target song info
                st.success(f"🎵 **{target['track_name']}** by **{target['artist_name']}**")
                
                cols = st.columns(6)
                cols[0].metric("Genre", target['genre'])
                cols[1].metric("Key", key_map.get(target['key'], 'Unknown'))
                cols[2].metric("Mode", "Major" if target['mode'] == 1 else "Minor")
                cols[3].metric("Dance", f"{target['danceability']:.2f}")
                cols[4].metric("Energy", f"{target['energy']:.2f}")
                cols[5].metric("Popularity", f"{target['popularity']}/100")
                
                # Prepare candidate songs with filters
                search_df = df.copy()
                
                # Apply filters
                if selected_genres:
                    search_df = search_df[search_df['genre'].isin(selected_genres)]
                
                search_df = search_df[
                    (search_df['danceability'] >= dance_target - dance_range) &
                    (search_df['danceability'] <= dance_target + dance_range) &
                    (search_df['energy'] >= energy_target - energy_range) &
                    (search_df['energy'] <= energy_target + energy_range) &
                    (search_df['valence'] >= valence_target - valence_range) &
                    (search_df['valence'] <= valence_target + valence_range) &
                    (search_df['tempo'] >= tempo_target - tempo_range) &
                    (search_df['tempo'] <= tempo_target + tempo_range) &
                    (search_df['popularity'] >= min_popularity) &
                    (search_df['duration_min'] <= max_duration) &
                    (search_df['instrumentalness'] <= instrumental_threshold) &
                    (search_df['speechiness'] <= speechiness_threshold)
                ]
                
                # Apply musical filters
                if key_filter_enabled and selected_key != 'Any':
                    target_key_index = key_names.index(selected_key)
                    if compatible_mode:
                        allowed_keys = get_harmonic_compatible_keys(target_key_index)
                        search_df = search_df[search_df['key'].isin(allowed_keys)]
                    else:
                        search_df = search_df[search_df['key'] == target_key_index]
                
                if mode_filter and selected_mode != "Both":
                    target_mode = 1 if selected_mode == "Major" else 0
                    search_df = search_df[search_df['mode'] == target_mode]
                
                # Remove target song from results
                search_df = search_df[search_df['track_id'] != target['track_id']]
                
                if len(search_df) > 0:
                    # Calculate similarities
                    similarities = calculate_similarity(target, search_df)
                    search_df['similarity'] = similarities
                    
                    # Get top recommendations
                    recommendations = search_df.nlargest(15, 'similarity')
                    
                    st.subheader(f"🎧 Top {len(recommendations)} Recommendations")
                    
                    # Display as interactive table
                    display_df = recommendations[['track_name', 'artist_name', 'genre', 
                                                'similarity', 'danceability', 'energy', 
                                                'valence', 'popularity']].copy()
                    display_df['similarity'] = display_df['similarity'].round(3)
                    display_df['Key'] = recommendations['key'].apply(lambda x: key_map.get(x, 'Unknown'))
                    display_df['Mode'] = recommendations['mode'].apply(lambda x: 'Major' if x == 1 else 'Minor')
                    
                    display_df = display_df.rename(columns={
                        'track_name': 'Song',
                        'artist_name': 'Artist',
                        'similarity': 'Match %',
                        'valence': 'Happiness'
                    })
                    
                    # Format similarity as percentage
                    display_df['Match %'] = (display_df['Match %'] * 100).round(1).astype(str) + '%'
                    
                    st.dataframe(
                        display_df,
                        use_container_width=True,
                        column_config={
                            "Song": st.column_config.TextColumn("Song", width="large"),
                            "Artist": st.column_config.TextColumn("Artist"),
                            "genre": st.column_config.TextColumn("Genre"),
                            "Match %": st.column_config.TextColumn("Match"),
                            "danceability": st.column_config.NumberColumn("Dance", format="%.2f"),
                            "energy": st.column_config.NumberColumn("Energy", format="%.2f"),
                            "Happiness": st.column_config.NumberColumn("Happy", format="%.2f"),
                            "popularity": st.column_config.ProgressColumn("Popularity", 
                                                                        min_value=0, max_value=100, 
                                                                        format="%d")
                        },
                        hide_index=True
                    )
                    
                    # Visualize feature comparison
                    with st.expander("📊 Feature Comparison"):
                        fig, axes = plt.subplots(1, 3, figsize=(12, 4))
                        
                        features_compare = ['danceability', 'energy', 'valence']
                        target_values = [target[f] for f in features_compare]
                        avg_values = [recommendations[f].mean() for f in features_compare]
                        
                        x = np.arange(len(features_compare))
                        width = 0.35
                        
                        axes[0].bar(x - width/2, target_values, width, label='Target Song', alpha=0.8)
                        axes[0].bar(x + width/2, avg_values, width, label='Recommendations Avg', alpha=0.8)
                        axes[0].set_xticks(x)
                        axes[0].set_xticklabels(['Dance', 'Energy', 'Happiness'])
                        axes[0].set_ylabel("Value")
                        axes[0].legend()
                        axes[0].set_title("Feature Comparison")
                        
                        # Tempo distribution
                        axes[1].hist(recommendations['tempo'], bins=15, alpha=0.7, edgecolor='black')
                        axes[1].axvline(target['tempo'], color='red', linestyle='--', label='Target')
                        axes[1].set_xlabel("Tempo (BPM)")
                        axes[1].set_ylabel("Count")
                        axes[1].legend()
                        axes[1].set_title("Tempo Distribution")
                        
                        # Popularity distribution
                        axes[2].hist(recommendations['popularity'], bins=15, alpha=0.7, 
                                   color='green', edgecolor='black')
                        axes[2].axvline(target['popularity'], color='red', linestyle='--', label='Target')
                        axes[2].set_xlabel("Popularity (0-100)")
                        axes[2].set_ylabel("Count")
                        axes[2].legend()
                        axes[2].set_title("Popularity Distribution")
                        
                        plt.tight_layout()
                        st.pyplot(fig)
                        
                else:
                    st.warning("No similar songs found with current filters.")
            else:
                st.error("Song not found in dataset!")

with tab2:
    st.header("Create Playlist")
    
    playlist_mode = st.radio(
        "Create playlist from:",
        ["🎛️ Mood & Features", "👤 Specific Artist", "🔤 Similar Song Names", "🎼 By Musical Key"],
        horizontal=True
    )
    
    if playlist_mode == "🎛️ Mood & Features":
        col1, col2 = st.columns(2)
        with col1:
            playlist_size = st.slider("Number of songs", 5, 100, 20)
        with col2:
            playlist_name = st.text_input("Playlist name", f"{selected_mood} Playlist")
        
        diversity = st.slider("Artist diversity", 0.0, 1.0, 0.7, 0.1,
                            help="Higher value prioritizes different artists")
    
    elif playlist_mode == "👤 Specific Artist":
        col1, col2, col3 = st.columns([3, 2, 1])
        with col1:
            artist_for_playlist = st.text_input("Artist name", "The Beatles")
        with col2:
            playlist_size = st.slider("Number of songs", 5, 50, 15)
        with col3:
            playlist_style = st.selectbox(
                "Playlist style",
                ["Artist Only", "Artist + Features", "Artist + Similar"]
            )
        
        playlist_name = st.text_input("Playlist name", f"{artist_for_playlist} Playlist")
        
        if playlist_style == "Artist + Similar":
            artist_percentage = st.slider("% Artist songs", 0, 100, 70)
    
    elif playlist_mode == "🔤 Similar Song Names":
        col1, col2 = st.columns(2)
        with col1:
            song_name_pattern = st.text_input("Song name pattern", "Love")
        with col2:
            playlist_size = st.slider("Number of songs", 5, 50, 15)
        
        playlist_name = st.text_input("Playlist name", f"Songs about {song_name_pattern}")
        
        match_strength = st.select_slider(
            "Match strength",
            options=["Loose", "Medium", "Strict"],
            value="Medium"
        )
    
    elif playlist_mode == "🎼 By Musical Key":
        col1, col2 = st.columns(2)
        with col1:
            selected_playlist_key = st.selectbox("Musical Key", key_names, index=0)
        with col2:
            playlist_size = st.slider("Number of songs", 5, 50, 15)
        
        playlist_name = st.text_input("Playlist name", f"{selected_playlist_key} Key Playlist")
        
        include_compatible = st.checkbox("Include harmonically compatible keys", True)
    
    if st.button("🎵 Generate Playlist", type="primary", use_container_width=True):
        with st.spinner("Creating your playlist..."):
            
            if playlist_mode == "🎛️ Mood & Features":
                playlist_df = df.copy()
                
                # Apply all filters
                if selected_genres:
                    playlist_df = playlist_df[playlist_df['genre'].isin(selected_genres)]
                
                playlist_df = playlist_df[
                    (playlist_df['danceability'] >= dance_target - dance_range) &
                    (playlist_df['danceability'] <= dance_target + dance_range) &
                    (playlist_df['energy'] >= energy_target - energy_range) &
                    (playlist_df['energy'] <= energy_target + energy_range) &
                    (playlist_df['valence'] >= valence_target - valence_range) &
                    (playlist_df['valence'] <= valence_target + valence_range) &
                    (playlist_df['tempo'] >= tempo_target - tempo_range) &
                    (playlist_df['tempo'] <= tempo_target + tempo_range) &
                    (playlist_df['popularity'] >= min_popularity) &
                    (playlist_df['duration_min'] <= max_duration)
                ]
                
                # Apply musical filters
                if key_filter_enabled and selected_key != 'Any':
                    target_key_index = key_names.index(selected_key)
                    if compatible_mode:
                        allowed_keys = get_harmonic_compatible_keys(target_key_index)
                        playlist_df = playlist_df[playlist_df['key'].isin(allowed_keys)]
                    else:
                        playlist_df = playlist_df[playlist_df['key'] == target_key_index]
                
                if mode_filter and selected_mode != "Both":
                    target_mode = 1 if selected_mode == "Major" else 0
                    playlist_df = playlist_df[playlist_df['mode'] == target_mode]
                
                # Ensure artist diversity
                if diversity > 0 and len(playlist_df) > 0:
                    unique_artists = playlist_df['artist_name'].unique()
                    if len(unique_artists) >= playlist_size * diversity:
                        # Sample with artist diversity
                        selected_songs = []
                        artists_selected = set()
                        
                        # Sort by popularity first
                        sorted_df = playlist_df.sort_values('popularity', ascending=False)
                        
                        for _, song in sorted_df.iterrows():
                            if len(selected_songs) >= playlist_size:
                                break
                            artist = song['artist_name']
                            if artist not in artists_selected or len(artists_selected) < playlist_size * diversity:
                                selected_songs.append(song)
                                artists_selected.add(artist)
                        
                        playlist = pd.DataFrame(selected_songs)
                    else:
                        playlist = playlist_df.sample(min(playlist_size, len(playlist_df)), random_state=42)
                else:
                    playlist = playlist_df.sample(min(playlist_size, len(playlist_df)), random_state=42)
                
                st.success(f"✅ **{playlist_name}** created with {len(playlist)} songs!")
            
            elif playlist_mode == "👤 Specific Artist":
                artist_pattern = artist_for_playlist.lower()
                artist_mask = df['artist_name'].str.lower().str.contains(artist_pattern, na=False)
                
                if not artist_mask.any():
                    st.error(f"Artist '{artist_for_playlist}' not found!")
                    similar_artists = df['artist_name'][df['artist_name'].str.lower().str.contains(artist_pattern[:4], na=False)].unique()[:5]
                    if len(similar_artists) > 0:
                        st.info(f"Did you mean: {', '.join(similar_artists)}?")
                    st.stop()
                
                artist_songs = df[artist_mask]
                
                if playlist_style == "Artist Only":
                    playlist = artist_songs.nlargest(min(playlist_size, len(artist_songs)), 'popularity')
                    st.success(f"✅ Created playlist with {len(playlist)} songs by {artist_for_playlist}!")
                
                elif playlist_style == "Artist + Features":
                    # Apply mood filters to artist songs
                    filtered_artist = artist_songs[
                        (artist_songs['danceability'] >= dance_target - dance_range) &
                        (artist_songs['danceability'] <= dance_target + dance_range) &
                        (artist_songs['energy'] >= energy_target - energy_range) &
                        (artist_songs['energy'] <= energy_target + energy_range)
                    ]
                    
                    if len(filtered_artist) > 0:
                        playlist = filtered_artist.nlargest(min(playlist_size, len(filtered_artist)), 'popularity')
                    else:
                        playlist = artist_songs.nlargest(min(playlist_size, len(artist_songs)), 'popularity')
                    
                    st.success(f"✅ Created mood-filtered playlist with {len(playlist)} songs!")
                
                elif playlist_style == "Artist + Similar":
                    artist_count = int(playlist_size * artist_percentage / 100)
                    similar_count = playlist_size - artist_count
                    
                    artist_playlist = artist_songs.nlargest(artist_count, 'popularity')
                    
                    if similar_count > 0:
                        # Find similar songs from other artists
                        artist_avg_features = artist_songs[['danceability', 'energy', 'valence', 'tempo']].mean()
                        
                        other_songs = df[~artist_mask].copy()
                        if selected_genres:
                            other_songs = other_songs[other_songs['genre'].isin(selected_genres)]
                        
                        # Calculate similarity to artist's average sound
                        similarities = []
                        for _, song in other_songs.iterrows():
                            diff = np.sqrt(((song[['danceability', 'energy', 'valence', 'tempo']] - artist_avg_features) ** 2).sum())
                            similarity = 1 / (1 + diff)
                            similarities.append(similarity)
                        
                        other_songs['similarity'] = similarities
                        similar_songs = other_songs.nlargest(similar_count * 2, 'similarity')
                        
                        # Ensure artist diversity
                        top_similar = []
                        seen_artists = set(artist_songs['artist_name'].unique())
                        for _, song in similar_songs.iterrows():
                            if song['artist_name'] not in seen_artists:
                                top_similar.append(song)
                                seen_artists.add(song['artist_name'])
                            if len(top_similar) >= similar_count:
                                break
                        
                        similar_playlist = pd.DataFrame(top_similar)
                        playlist = pd.concat([artist_playlist, similar_playlist]).head(playlist_size)
                    else:
                        playlist = artist_playlist
                    
                    st.success(f"✅ Created playlist with {artist_count} artist songs + {similar_count} similar songs!")
            
            elif playlist_mode == "🔤 Similar Song Names":
                if match_strength == "Strict":
                    pattern = r'\b' + song_name_pattern + r'\b'
                    name_mask = df['track_name'].str.contains(pattern, case=False, na=False, regex=True)
                elif match_strength == "Medium":
                    name_mask = df['track_name'].str.contains(r'\b' + song_name_pattern + r'\w*', case=False, na=False, regex=True)
                else:
                    name_mask = df['track_name'].str.contains(song_name_pattern, case=False, na=False)
                
                name_songs = df[name_mask]
                
                if len(name_songs) == 0:
                    st.error(f"No songs found with name containing '{song_name_pattern}'!")
                    st.stop()
                
                # Apply mood filters
                filtered_songs = name_songs.copy()
                
                if selected_genres:
                    filtered_songs = filtered_songs[filtered_songs['genre'].isin(selected_genres)]
                
                filtered_songs = filtered_songs[
                    (filtered_songs['danceability'] >= dance_target - dance_range) &
                    (filtered_songs['danceability'] <= dance_target + dance_range) &
                    (filtered_songs['energy'] >= energy_target - energy_range) &
                    (filtered_songs['energy'] <= energy_target + energy_range) &
                    (filtered_songs['popularity'] >= min_popularity) &
                    (filtered_songs['duration_min'] <= max_duration)
                ]
                
                if len(filtered_songs) >= playlist_size:
                    playlist = filtered_songs.sample(playlist_size, random_state=42)
                else:
                    playlist = filtered_songs
                
                st.success(f"✅ **{playlist_name}** created with {len(playlist)} songs about '{song_name_pattern}'!")
            
            elif playlist_mode == "🎼 By Musical Key":
                target_key_index = key_names.index(selected_playlist_key)
                
                if include_compatible:
                    allowed_keys = get_harmonic_compatible_keys(target_key_index)
                    key_mask = df['key'].isin(allowed_keys)
                else:
                    key_mask = df['key'] == target_key_index
                
                key_songs = df[key_mask]
                
                if len(key_songs) == 0:
                    st.error(f"No songs found in {selected_playlist_key} key!")
                    st.stop()
                
                # Apply mood filters
                filtered_key = key_songs.copy()
                
                if selected_genres:
                    filtered_key = filtered_key[filtered_key['genre'].isin(selected_genres)]
                
                filtered_key = filtered_key[
                    (filtered_key['danceability'] >= dance_target - dance_range) &
                    (filtered_key['danceability'] <= dance_target + dance_range) &
                    (filtered_key['energy'] >= energy_target - energy_range) &
                    (filtered_key['energy'] <= energy_target + energy_range) &
                    (filtered_key['popularity'] >= min_popularity) &
                    (filtered_key['duration_min'] <= max_duration)
                ]
                
                if len(filtered_key) >= playlist_size:
                    playlist = filtered_key.sample(playlist_size, random_state=42)
                else:
                    playlist = filtered_key
                
                st.success(f"✅ **{playlist_name}** created with {len(playlist)} songs in {selected_playlist_key} key!")
            
            # ========== DISPLAY PLAYLIST ==========
            if 'playlist' in locals() and len(playlist) > 0:
                playlist = playlist.sort_values('energy')
                
                total_minutes = playlist['duration_min'].sum()
                avg_popularity = playlist['popularity'].mean()
                avg_danceability = playlist['danceability'].mean()
                avg_energy = playlist['energy'].mean()
                
                cols = st.columns(4)
                cols[0].metric("Total Duration", f"{total_minutes:.1f} min")
                cols[1].metric("Avg Popularity", f"{avg_popularity:.1f}/100")
                cols[2].metric("Artists", playlist['artist_name'].nunique())
                cols[3].metric("Genres", playlist['genre'].nunique())
                
                # Feature averages
                cols2 = st.columns(4)
                cols2[0].metric("Avg Dance", f"{avg_danceability:.2f}")
                cols2[1].metric("Avg Energy", f"{avg_energy:.2f}")
                cols2[2].metric("Avg Happiness", f"{playlist['valence'].mean():.2f}")
                cols2[3].metric("Avg Tempo", f"{playlist['tempo'].mean():.0f} BPM")
                
                st.subheader("🎶 Playlist Tracks")
                
                # Create display dataframe
                playlist_display = playlist[['track_name', 'artist_name', 'genre', 
                                           'popularity', 'duration_min', 'danceability',
                                           'energy', 'valence']].copy()
                playlist_display['duration'] = playlist_display['duration_min'].apply(lambda x: f"{x:.1f} min")
                playlist_display['Key'] = playlist['key'].apply(lambda x: key_map.get(x, 'Unknown'))
                playlist_display['Mode'] = playlist['mode'].apply(lambda x: 'Major' if x == 1 else 'Minor')
                
                playlist_display = playlist_display.rename(columns={
                    'track_name': 'Song',
                    'artist_name': 'Artist',
                    'genre': 'Genre',
                    'popularity': 'Popularity',
                    'danceability': 'Dance',
                    'energy': 'Energy',
                    'valence': 'Happiness'
                }).drop(columns=['duration_min'])
                
                playlist_display.index = range(1, len(playlist_display) + 1)
                
                st.dataframe(
                    playlist_display,
                    use_container_width=True,
                    column_config={
                        "Song": st.column_config.TextColumn("Song", width="large"),
                        "Artist": st.column_config.TextColumn("Artist", width="medium"),
                        "Genre": st.column_config.TextColumn("Genre", width="small"),
                        "Popularity": st.column_config.ProgressColumn("Popularity", min_value=0, max_value=100, format="%d"),
                        "duration": st.column_config.TextColumn("Duration"),
                        "Dance": st.column_config.NumberColumn("Dance", format="%.2f"),
                        "Energy": st.column_config.NumberColumn("Energy", format="%.2f"),
                        "Happiness": st.column_config.NumberColumn("Happy", format="%.2f"),
                        "Key": st.column_config.TextColumn("Key"),
                        "Mode": st.column_config.TextColumn("Mode")
                    }
                )
                
                # Visualization
                with st.expander("📊 Playlist Analysis"):
                    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
                    
                    # Genre distribution
                    genre_counts = playlist['genre'].value_counts().head(8)
                    axes[0, 0].pie(genre_counts.values, labels=genre_counts.index, autopct='%1.1f%%')
                    axes[0, 0].set_title("Genre Distribution")
                    
                    # Popularity distribution
                    axes[0, 1].hist(playlist['popularity'], bins=15, alpha=0.7, color='green', edgecolor='black')
                    axes[0, 1].set_xlabel("Popularity")
                    axes[0, 1].set_ylabel("Count")
                    axes[0, 1].set_title("Popularity Distribution")
                    
                    # Feature radar (average values)
                    features = ['danceability', 'energy', 'valence', 'acousticness', 'instrumentalness']
                    avg_values = [playlist[f].mean() for f in features]
                    
                    angles = np.linspace(0, 2*np.pi, len(features), endpoint=False).tolist()
                    avg_values += avg_values[:1]
                    angles += angles[:1]
                    
                    ax = axes[1, 0]
                    ax = plt.subplot(2, 2, 3, polar=True)
                    ax.plot(angles, avg_values, 'o-', linewidth=2)
                    ax.fill(angles, avg_values, alpha=0.25)
                    ax.set_xticks(angles[:-1])
                    ax.set_xticklabels(['Dance', 'Energy', 'Happy', 'Acoustic', 'Instrumental'])
                    ax.set_ylim(0, 1)
                    ax.set_title("Audio Feature Profile")
                    
                    # Duration distribution
                    axes[1, 1].hist(playlist['duration_min'], bins=15, alpha=0.7, color='purple', edgecolor='black')
                    axes[1, 1].axvline(playlist['duration_min'].mean(), color='red', linestyle='--', label=f"Avg: {playlist['duration_min'].mean():.1f} min")
                    axes[1, 1].set_xlabel("Duration (minutes)")
                    axes[1, 1].set_ylabel("Count")
                    axes[1, 1].legend()
                    axes[1, 1].set_title("Song Duration Distribution")
                    
                    plt.tight_layout()
                    st.pyplot(fig)
                
                # Export options
                st.subheader("💾 Export Playlist")
                
                csv_data = playlist[['track_name', 'artist_name', 'genre', 'popularity', 
                                   'danceability', 'energy', 'valence', 'tempo', 
                                   'duration_ms', 'key', 'mode']].copy()
                csv_data['duration_min'] = csv_data['duration_ms'] / 60000
                csv_data['key_name'] = csv_data['key'].apply(lambda x: key_map.get(x, 'Unknown'))
                csv_data['mode_name'] = csv_data['mode'].apply(lambda x: 'Major' if x == 1 else 'Minor')
                csv_data = csv_data.drop(columns=['duration_ms', 'key', 'mode'])
                csv_data = csv_data.rename(columns={
                    'track_name': 'Song_Name',
                    'artist_name': 'Artist_Name',
                    'genre': 'Genre',
                    'popularity': 'Popularity',
                    'danceability': 'Danceability',
                    'energy': 'Energy',
                    'valence': 'Happiness',
                    'tempo': 'Tempo_BPM',
                    'duration_min': 'Duration_Min',
                    'key_name': 'Key',
                    'mode_name': 'Mode'
                })
                
                csv = csv_data.to_csv(index=False)
                
                # Spotify-style text format
                spotify_text = f"{playlist_name}\n"
                spotify_text += "=" * 50 + "\n\n"
                for i, (_, song) in enumerate(playlist.iterrows(), 1):
                    spotify_text += f"{i}. {song['track_name']} - {song['artist_name']}\n"
                    spotify_text += f"   Genre: {song['genre']} | Popularity: {song['popularity']}/100\n"
                    spotify_text += f"   Dance: {song['danceability']:.2f} | Energy: {song['energy']:.2f} | Happy: {song['valence']:.2f}\n"
                    spotify_text += f"   Key: {key_map.get(song['key'], 'Unknown')} | Tempo: {song['tempo']:.0f} BPM\n"
                    spotify_text += "\n"
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.download_button(
                        label="📥 Download as CSV",
                        data=csv,
                        file_name=f"{playlist_name.replace(' ', '_')}.csv",
                        mime="text/csv",
                        type="primary",
                        use_container_width=True
                    )
                with col2:
                    st.download_button(
                        label="📝 Download as Text",
                        data=spotify_text,
                        file_name=f"{playlist_name.replace(' ', '_')}.txt",
                        mime="text/plain",
                        use_container_width=True
                    )
                with col3:
                    json_data = playlist[['track_name', 'artist_name', 'genre', 
                                        'popularity', 'danceability', 'energy', 
                                        'valence', 'tempo']].to_json(orient='records', indent=2)
                    st.download_button(
                        label="📊 Download as JSON",
                        data=json_data,
                        file_name=f"{playlist_name.replace(' ', '_')}.json",
                        mime="application/json",
                        use_container_width=True
                    )

with tab3:
    st.header("📊 Explore Dataset")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Songs", f"{len(df):,}")
    col2.metric("Unique Artists", df['artist_name'].nunique())
    col3.metric("Genres", df['genre'].nunique())
    col4.metric("Avg Popularity", f"{df['popularity'].mean():.1f}/100")
    
    # Genre distribution
    st.subheader("🎵 Genre Distribution")
    top_genres = df['genre'].value_counts().head(15)
    
    fig1, ax1 = plt.subplots(figsize=(10, 6))
    top_genres.plot(kind='barh', ax=ax1, color='lightblue')
    ax1.set_xlabel("Number of Songs")
    ax1.set_title("Top 15 Genres by Song Count")
    plt.tight_layout()
    st.pyplot(fig1)
    
    # Audio features exploration
    st.subheader("📈 Audio Features Analysis")
    
    feature_cols = ['danceability', 'energy', 'valence', 'acousticness', 
                   'instrumentalness', 'liveness', 'speechiness']
    
    selected_feature = st.selectbox("Select feature to explore", feature_cols)
    
    fig2, (ax2, ax3) = plt.subplots(1, 2, figsize=(14, 5))
    
    # Histogram
    ax2.hist(df[selected_feature].dropna(), bins=30, alpha=0.7, color='lightgreen', edgecolor='black')
    ax2.set_title(f"Distribution of {selected_feature}")
    ax2.set_xlabel(selected_feature.capitalize())
    ax2.set_ylabel("Count")
    
    # Boxplot by top genres
    top_5_genres = df['genre'].value_counts().head(5).index
    genre_data = [df[df['genre'] == genre][selected_feature].dropna() for genre in top_5_genres]
    
    box = ax3.boxplot(genre_data, labels=top_5_genres, patch_artist=True)
    for patch in box['boxes']:
        patch.set_facecolor('lightcoral')
    
    ax3.set_title(f"{selected_feature} by Top 5 Genres")
    ax3.set_xticklabels(top_5_genres, rotation=45, ha='right')
    ax3.set_ylabel(selected_feature.capitalize())
    
    plt.tight_layout()
    st.pyplot(fig2)
    
    # Musical analysis
    st.subheader("🎼 Music Theory Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Key distribution - SAFE VERSION
        fig_key, ax_key = plt.subplots(figsize=(8, 5))
        
        # Get key counts
        key_counts = df['key'].value_counts()
        
        # Handle non-numeric keys
        valid_keys = []
        valid_counts = []
        
        for key_val, count in key_counts.items():
            try:
                # Try to convert to integer
                key_int = int(float(key_val))  # Handle floats too
                if 0 <= key_int <= 11:  # Valid key range
                    valid_keys.append(key_names[key_int])
                    valid_counts.append(count)
                else:
                    # Invalid number, skip or label as unknown
                    pass
            except (ValueError, TypeError):
                # Not a number, skip this key
                pass
        
        # Plot only valid keys
        if valid_keys and valid_counts:
            ax_key.bar(valid_keys, valid_counts, color='skyblue')
            ax_key.set_title("Distribution of Musical Keys (Valid Only)")
            ax_key.set_xlabel("Key")
            ax_key.set_ylabel("Number of Songs")
            plt.xticks(rotation=45)
            st.pyplot(fig_key)
        else:
            st.write("No valid key data to display")
    
    with col2:
        # Major vs Minor
        fig_mode, ax_mode = plt.subplots(figsize=(6, 5))
        mode_counts = df['mode'].value_counts()
        colors = ['#ff9999', '#66b3ff']
        ax_mode.pie(mode_counts.values, labels=['Minor', 'Major'], 
                   autopct='%1.1f%%', colors=colors, startangle=90)
        ax_mode.set_title("Major vs Minor Songs")
        st.pyplot(fig_mode)
    
    # Time signature
    st.subheader("⏱️ Rhythm Analysis")
    try:
        # Get time signature counts
        time_counts = df['time_signature'].value_counts().sort_index()
        
        # Create labels safely
        time_labels = []
        for ts in time_counts.index:
            try:
                if pd.isna(ts):
                    time_labels.append("Unknown")
                elif isinstance(ts, str):
                    if '/' in ts:
                        # Handle "4/4" format
                        time_labels.append(ts)
                    else:
                        # Try to convert string to number
                        time_labels.append(f"{int(float(ts))}/4")
                else:
                    # Handle numeric values
                    time_labels.append(f"{int(ts)}/4")
            except:
                time_labels.append(str(ts))
        
        # Plot
        fig_time, ax_time = plt.subplots(figsize=(10, 4))
        ax_time.bar(time_labels, time_counts.values, color='lightseagreen')
        ax_time.set_title("Time Signatures Distribution")
        ax_time.set_xlabel("Time Signature")
        ax_time.set_ylabel("Count")
        st.pyplot(fig_time)
        
    except Exception as e:
        st.error(f"Could not display time signature analysis: {str(e)}")
        # Show the data as table instead
        st.write("Time Signature Data:")
        st.dataframe(df['time_signature'].value_counts())
    
    # Correlation heatmap
    with st.expander("🔗 Feature Correlations"):
        corr_features = ['danceability', 'energy', 'valence', 'acousticness', 
                        'instrumentalness', 'liveness', 'speechiness', 'tempo', 
                        'loudness_norm', 'popularity']
        corr_matrix = df[corr_features].corr()
        
        fig_corr, ax_corr = plt.subplots(figsize=(10, 8))
        im = ax_corr.imshow(corr_matrix, cmap='coolwarm', vmin=-1, vmax=1)
        ax_corr.set_xticks(range(len(corr_features)))
        ax_corr.set_yticks(range(len(corr_features)))
        ax_corr.set_xticklabels(corr_features, rotation=45, ha='right')
        ax_corr.set_yticklabels(corr_features)
        
        # Add correlation values
        for i in range(len(corr_features)):
            for j in range(len(corr_features)):
                text = ax_corr.text(j, i, f'{corr_matrix.iloc[i, j]:.2f}',
                                   ha="center", va="center", color="black", fontsize=8)
        
        plt.colorbar(im)
        ax_corr.set_title("Audio Features Correlation Matrix")
        plt.tight_layout()
        st.pyplot(fig_corr)
    
    # Sample songs
    st.subheader("🎧 Sample Songs Explorer")
    
    sample_filter = st.selectbox(
        "Filter sample", 
        ["All", "High Popularity (>80)", "Low Popularity (<20)", 
         "High Danceability (>0.8)", "High Energy (>0.8)", "Specific Genre"],
        key="sample_filter"
    )
    
    sample_df = df.copy()
    if sample_filter == "High Popularity (>80)":
        sample_df = sample_df[sample_df['popularity'] > 80]
    elif sample_filter == "Low Popularity (<20)":
        sample_df = sample_df[sample_df['popularity'] < 20]
    elif sample_filter == "High Danceability (>0.8)":
        sample_df = sample_df[sample_df['danceability'] > 0.8]
    elif sample_filter == "High Energy (>0.8)":
        sample_df = sample_df[sample_df['energy'] > 0.8]
    elif sample_filter == "Specific Genre":
        specific_genre = st.selectbox("Select genre", sorted(df['genre'].unique()))
        sample_df = sample_df[sample_df['genre'] == specific_genre]
    
    if len(sample_df) > 0:
        sample_size = st.slider("Number of samples", 5, 50, 10)
        sample = sample_df.sample(min(sample_size, len(sample_df)))[
            ['track_name', 'artist_name', 'genre', 'popularity', 
             'danceability', 'energy', 'valence', 'tempo']
        ]
        sample = sample.sort_values('popularity', ascending=False)
        sample.index = range(1, len(sample) + 1)
        
        st.dataframe(
            sample,
            use_container_width=True,
            column_config={
                "track_name": st.column_config.TextColumn("Song", width="large"),
                "artist_name": st.column_config.TextColumn("Artist"),
                "genre": st.column_config.TextColumn("Genre"),
                "popularity": st.column_config.ProgressColumn("Popularity", min_value=0, max_value=100, format="%d"),
                "danceability": st.column_config.NumberColumn("Dance", format="%.2f"),
                "energy": st.column_config.NumberColumn("Energy", format="%.2f"),
                "valence": st.column_config.NumberColumn("Happy", format="%.2f"),
                "tempo": st.column_config.NumberColumn("Tempo", format="%.0f")
            }
        )

with tab4:
    st.header("📈 Mood Analysis")
    
    # Mood categorization based on valence and energy
    st.subheader("🎭 Mood Distribution in Dataset")
    
    # Create 4-quadrant mood classification
    df['mood_quadrant'] = pd.cut(
        df['valence'],
        bins=[0, 0.4, 0.7, 1],
        labels=['Low Valence', 'Medium Valence', 'High Valence']
    )
    
    df['energy_level'] = pd.cut(
        df['energy'],
        bins=[0, 0.4, 0.7, 1],
        labels=['Low Energy', 'Medium Energy', 'High Energy']
    )
    
    # Create mood matrix
    mood_matrix = df.groupby(['mood_quadrant', 'energy_level']).size().unstack(fill_value=0)
    
    fig_mood, ax_mood = plt.subplots(figsize=(10, 6))
    im = ax_mood.imshow(mood_matrix.values, cmap='YlOrRd', aspect='auto')
    
    ax_mood.set_xticks(np.arange(len(mood_matrix.columns)))
    ax_mood.set_yticks(np.arange(len(mood_matrix.index)))
    ax_mood.set_xticklabels(mood_matrix.columns)
    ax_mood.set_yticklabels(mood_matrix.index)
    
    # Add count labels
    for i in range(len(mood_matrix.index)):
        for j in range(len(mood_matrix.columns)):
            text = ax_mood.text(j, i, mood_matrix.iloc[i, j],
                               ha="center", va="center", color="black")
    
    plt.colorbar(im)
    ax_mood.set_title("Mood Distribution: Valence vs Energy")
    plt.tight_layout()
    st.pyplot(fig_mood)
    
    # Mood by genre
    st.subheader("🎵 Mood by Genre")
    
    top_genres_mood = st.slider("Number of top genres to show", 5, 20, 10)
    top_genres_list = df['genre'].value_counts().head(top_genres_mood).index
    
    mood_by_genre = df[df['genre'].isin(top_genres_list)].groupby('genre').agg({
        'valence': 'mean',
        'energy': 'mean',
        'danceability': 'mean',
        'popularity': 'mean'
    }).round(3)
    
    st.dataframe(
        mood_by_genre,
        use_container_width=True,
        column_config={
            "valence": st.column_config.NumberColumn("Happiness", format="%.3f"),
            "energy": st.column_config.NumberColumn("Energy", format="%.3f"),
            "danceability": st.column_config.NumberColumn("Dance", format="%.3f"),
            "popularity": st.column_config.NumberColumn("Popularity", format="%.1f")
        }
    )
    
    # Mood trends visualization
    st.subheader("📊 Mood Trends Visualization")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Valence vs Energy scatter
        fig_scatter, ax_scatter = plt.subplots(figsize=(8, 6))
        scatter = ax_scatter.scatter(df['valence'], df['energy'], 
                                    c=df['danceability'], alpha=0.5, 
                                    cmap='viridis', s=20)
        ax_scatter.set_xlabel("Valence (Happiness)")
        ax_scatter.set_ylabel("Energy")
        ax_scatter.set_title("Valence vs Energy (colored by Danceability)")
        plt.colorbar(scatter, label='Danceability')
        st.pyplot(fig_scatter)
    
    with col2:
        # Popularity by mood
        fig_pop_mood, ax_pop_mood = plt.subplots(figsize=(8, 6))
        
        # Categorize songs into mood groups
        def get_mood_group(valence, energy):
            if valence > 0.6 and energy > 0.6:
                return "Happy/Energetic"
            elif valence > 0.6 and energy <= 0.6:
                return "Happy/Calm"
            elif valence <= 0.6 and energy > 0.6:
                return "Sad/Energetic"
            else:
                return "Sad/Calm"
        
        df['mood_group'] = df.apply(lambda x: get_mood_group(x['valence'], x['energy']), axis=1)
        mood_popularity = df.groupby('mood_group')['popularity'].mean().sort_values()
        
        mood_popularity.plot(kind='barh', ax=ax_pop_mood, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'])
        ax_pop_mood.set_xlabel("Average Popularity")
        ax_pop_mood.set_title("Popularity by Mood Group")
        st.pyplot(fig_pop_mood)
    
    # Mood prediction info
    with st.expander("🧠 How Mood Prediction Works"):
        st.markdown("""
        ### Mood Classification Algorithm
        
        Our system uses **audio features** from Spotify to predict song mood:
        
        **1. Valence (Happiness):** 0-1 scale
        - High (>0.7): Positive, cheerful emotions
        - Medium (0.4-0.7): Neutral emotions
        - Low (<0.4): Sad, melancholy emotions
        
        **2. Energy:** 0-1 scale  
        - High (>0.7): Intense, powerful
        - Medium (0.4-0.7): Moderate energy
        - Low (<0.4): Calm, relaxed
        
        **3. Combined Mood Quadrants:**
        - **Happy/Energetic:** High valence + high energy
        - **Happy/Calm:** High valence + low energy
        - **Sad/Energetic:** Low valence + high energy
        - **Sad/Calm:** Low valence + low energy
        
        **Additional features considered:**
        - **Danceability:** Rhythm regularity
        - **Acousticness:** Acoustic vs electronic
        - **Tempo:** Speed (BPM)
        - **Loudness:** Volume intensity
        
        The recommendation system weights these features differently based on:
        - Selected mood profile
        - Target song's genre
        - User preferences (sliders)
        """)

# Footer
st.divider()
st.markdown("""
<div style="text-align: center">
    <p>🎵 <b>Spotify Mood DJ</b> • Created with ❤️ using Streamlit</p>
    <p style="font-size: 0.8em; color: #666;">
        Uses Spotify audio features for intelligent mood-based music recommendation<br>
        Dataset: SpotifyFeatures from Kaggle • Features: 18 audio attributes per song
    </p>
</div>
""", unsafe_allow_html=True)